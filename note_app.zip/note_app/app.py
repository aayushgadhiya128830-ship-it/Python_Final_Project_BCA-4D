import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_migrate import Migrate
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from datetime import datetime
import pytz
from markdown import markdown
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///notes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

from models import db, User, Note, Tag
db.init_app(app)
migrate = Migrate(app, db)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Helper
def timezone_now():
    if current_user.is_authenticated and current_user.timezone:
        tz = pytz.timezone(current_user.timezone)
        return datetime.now(tz)
    return datetime.utcnow()

# Routes
@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            flash('Welcome back!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash('Username already taken', 'warning')
        elif User.query.filter_by(email=email).first():
            flash('Email already registered', 'warning')
        else:
            user = User(username=username, email=email)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            flash('Account created! Please log in.', 'success')
            return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    filter_type = request.args.get('filter', 'all')
    search = request.args.get('search', '')
    query = Note.query.filter_by(user_id=current_user.id, is_deleted=False)
    
    if filter_type == 'archived':
        query = query.filter_by(is_archived=True)
    elif filter_type == 'expired':
        query = query.filter(Note.expiry_date < datetime.utcnow())
    elif filter_type == 'high_priority':
        query = query.filter_by(priority='high')
    elif filter_type == 'medium_priority':
        query = query.filter_by(priority='medium')
    elif filter_type == 'low_priority':
        query = query.filter_by(priority='low')
    else:
        query = query.filter_by(is_archived=False)
    
    if search:
        query = query.filter(
            Note.title.contains(search) | Note.content.contains(search)
        )
    
    notes = query.order_by(Note.updated_at.desc()).all()
    return render_template('dashboard.html', notes=notes, filter=filter_type, search=search)

@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_note():
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        priority = request.form.get('priority', 'medium')
        reminder = request.form.get('reminder_time')
        expiry = request.form.get('expiry_date')
        due = request.form.get('due_date')
        tags_str = request.form.get('tags', '')
        
        note = Note(title=title, content=content, priority=priority, user_id=current_user.id)
        if reminder:
            note.reminder_time = datetime.fromisoformat(reminder)
        if expiry:
            note.expiry_date = datetime.fromisoformat(expiry)
        if due:
            note.due_date = datetime.fromisoformat(due)
        
        db.session.add(note)
        db.session.commit()
        
        for tag_name in [t.strip() for t in tags_str.split(',') if t.strip()]:
            tag = Tag.query.filter_by(name=tag_name).first()
            if not tag:
                tag = Tag(name=tag_name)
                db.session.add(tag)
            note.tags.append(tag)
        db.session.commit()
        
        flash('Note created!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('add_note.html')

@app.route('/edit/<int:note_id>', methods=['GET', 'POST'])
@login_required
def edit_note(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id, is_deleted=False).first_or_404()
    if request.method == 'POST':
        note.title = request.form['title']
        note.content = request.form['content']
        note.priority = request.form.get('priority', 'medium')
        note.reminder_time = datetime.fromisoformat(request.form['reminder_time']) if request.form.get('reminder_time') else None
        note.expiry_date = datetime.fromisoformat(request.form['expiry_date']) if request.form.get('expiry_date') else None
        note.due_date = datetime.fromisoformat(request.form['due_date']) if request.form.get('due_date') else None
        
        tags_str = request.form.get('tags', '')
        note.tags.clear()
        for tag_name in [t.strip() for t in tags_str.split(',') if t.strip()]:
            tag = Tag.query.filter_by(name=tag_name).first()
            if not tag:
                tag = Tag(name=tag_name)
                db.session.add(tag)
            note.tags.append(tag)
        db.session.commit()
        flash('Note updated', 'success')
        return redirect(url_for('dashboard'))
    
    tags_str = ', '.join([t.name for t in note.tags])
    return render_template('edit_note.html', note=note, tags=tags_str)

@app.route('/delete/<int:note_id>')
@login_required
def soft_delete(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id).first_or_404()
    note.is_deleted = True
    note.deleted_at = datetime.utcnow()
    db.session.commit()
    flash('Note moved to trash', 'info')
    return redirect(url_for('dashboard'))

@app.route('/trash')
@login_required
def trash():
    notes = Note.query.filter_by(user_id=current_user.id, is_deleted=True).order_by(Note.deleted_at.desc()).all()
    return render_template('trash.html', notes=notes)

@app.route('/restore/<int:note_id>')
@login_required
def restore_note(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id, is_deleted=True).first_or_404()
    note.is_deleted = False
    note.deleted_at = None
    db.session.commit()
    flash('Note restored', 'success')
    return redirect(url_for('trash'))

@app.route('/permanent/<int:note_id>')
@login_required
def permanent_delete(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id, is_deleted=True).first_or_404()
    db.session.delete(note)
    db.session.commit()
    flash('Note permanently deleted', 'danger')
    return redirect(url_for('trash'))

@app.route('/archive/<int:note_id>')
@login_required
def archive_note(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id, is_deleted=False).first_or_404()
    note.is_archived = not note.is_archived
    db.session.commit()
    flash('Note archived' if note.is_archived else 'Note unarchived', 'info')
    return redirect(url_for('dashboard'))

@app.route('/share/<int:note_id>')
@login_required
def share_note(note_id):
    note = Note.query.filter_by(id=note_id, user_id=current_user.id, is_deleted=False).first_or_404()
    if not note.share_token:
        note.generate_share_token()
        db.session.commit()
    share_url = url_for('view_shared', token=note.share_token, _external=True)
    return render_template('shared_note.html', share_url=share_url, note=note)

@app.route('/shared/<token>')
def view_shared(token):
    note = Note.query.filter_by(share_token=token, is_deleted=False).first_or_404()
    html_content = markdown(note.content) if note.content else ''
    return render_template('view_shared.html', note=note, content_html=html_content)

@app.route('/export')
@login_required
def export_notes():
    notes = Note.query.filter_by(user_id=current_user.id, is_deleted=False).all()
    export = [{
        'title': n.title,
        'content': n.content,
        'created': n.created_at.isoformat(),
        'updated': n.updated_at.isoformat(),
        'priority': n.priority,
        'tags': [t.name for t in n.tags]
    } for n in notes]
    return jsonify(export)

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        current_user.email = request.form['email']
        current_user.timezone = request.form['timezone']
        new_password = request.form.get('new_password')
        if new_password:
            current_user.set_password(new_password)
        db.session.commit()
        flash('Profile updated', 'success')
        return redirect(url_for('profile'))
    return render_template('profile.html', user=current_user)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    # Run on port 8080 instead of default 5000
    app.run(host='0.0.0.0', debug=True, port=8080)