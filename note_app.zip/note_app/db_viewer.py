import sqlite3
import os
from flask import Flask, render_template_string, jsonify, request
from datetime import datetime, timedelta
import json

app = Flask(__name__)

# Database path
DB_PATH = os.path.join('instance', 'notes.db')

# HTML Template with Premium UI/UX
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NovaNotes Analytics Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #1f2937;
            overflow-x: hidden;
        }

        /* Animated Background */
        .animated-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .animated-bg::before {
            content: '';
            position: absolute;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 1px, transparent 1px);
            background-size: 50px 50px;
            animation: moveBackground 20s linear infinite;
        }

        @keyframes moveBackground {
            0% { transform: translate(0, 0); }
            100% { transform: translate(50px, 50px); }
        }

        /* Main Container */
        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
            position: relative;
            z-index: 1;
        }

        /* Glass Header */
        .glass-header {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 30px;
            padding: 30px 40px;
            margin-bottom: 30px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            animation: slideDown 0.6s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }

        .logo-section h1 {
            font-size: 2rem;
            background: linear-gradient(135deg, #fff, #e0e7ff);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 5px;
        }

        .logo-section p {
            color: rgba(255,255,255,0.8);
            font-size: 0.9rem;
        }

        .refresh-btn {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            padding: 12px 24px;
            border-radius: 50px;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .refresh-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: translateY(-2px);
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            animation: fadeInUp 0.6s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.5s;
        }

        .stat-card:hover::before {
            left: 100%;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.15);
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            color: white;
            margin-bottom: 5px;
        }

        .stat-label {
            color: rgba(255,255,255,0.7);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .stat-trend {
            margin-top: 10px;
            font-size: 0.8rem;
            color: #10b981;
        }

        /* Charts Grid */
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 25px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease;
        }

        .chart-card:hover {
            transform: translateY(-5px);
        }

        .chart-title {
            color: white;
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        canvas {
            max-height: 300px;
        }

        /* Tabs */
        .tabs {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            flex-wrap: wrap;
        }

        .tab-btn {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 12px 28px;
            border-radius: 50px;
            cursor: pointer;
            color: white;
            font-weight: 500;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .tab-btn i {
            margin-right: 8px;
        }

        .tab-btn:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border-color: transparent;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        /* Table Container */
        .table-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 20px;
            overflow-x: auto;
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            color: white;
        }

        .data-table th {
            text-align: left;
            padding: 15px 12px;
            background: rgba(255, 255, 255, 0.1);
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .data-table td {
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 0.85rem;
        }

        .data-table tr:hover {
            background: rgba(255, 255, 255, 0.05);
            cursor: pointer;
        }

        /* Badges */
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-high {
            background: #ef4444;
            color: white;
        }

        .badge-medium {
            background: #f59e0b;
            color: white;
        }

        .badge-low {
            background: #10b981;
            color: white;
        }

        .badge-active {
            background: #10b981;
            color: white;
        }

        .badge-archived {
            background: #f59e0b;
            color: white;
        }

        .badge-deleted {
            background: #ef4444;
            color: white;
        }

        /* Tags */
        .tag {
            display: inline-block;
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.7rem;
            margin: 2px;
            color: white;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(10px);
            z-index: 1000;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
            color: #1f2937;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .close-modal {
            cursor: pointer;
            font-size: 1.5rem;
        }

        /* Loading */
        .loading {
            text-align: center;
            padding: 40px;
            color: white;
        }

        /* Search Box */
        .search-box {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }

        .search-input {
            flex: 1;
            padding: 12px 20px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 50px;
            color: white;
            font-size: 0.9rem;
        }

        .search-input::placeholder {
            color: rgba(255,255,255,0.6);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .dashboard-container {
                padding: 10px;
            }
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .charts-grid {
                grid-template-columns: 1fr;
            }
            .glass-header {
                padding: 20px;
            }
            .header-content {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="animated-bg"></div>
    
    <div class="dashboard-container">
        <!-- Header -->
        <div class="glass-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1><i class="fas fa-database"></i> NovaNotes Analytics</h1>
                    <p>Comprehensive Database Management Dashboard</p>
                </div>
                <div>
                    <button class="refresh-btn" onclick="refreshAll()">
                        <i class="fas fa-sync-alt"></i> Refresh Data
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid" id="statsGrid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value" id="totalUsers">-</div>
                <div class="stat-label">Total Users</div>
                <div class="stat-trend" id="userTrend"></div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-sticky-note"></i></div>
                <div class="stat-value" id="totalNotes">-</div>
                <div class="stat-label">Total Notes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                <div class="stat-value" id="activeNotes">-</div>
                <div class="stat-label">Active Notes</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-archive"></i></div>
                <div class="stat-value" id="archivedNotes">-</div>
                <div class="stat-label">Archived</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-trash"></i></div>
                <div class="stat-value" id="deletedNotes">-</div>
                <div class="stat-label">Deleted</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-tags"></i></div>
                <div class="stat-value" id="totalTags">-</div>
                <div class="stat-label">Total Tags</div>
            </div>
        </div>

        <!-- Charts -->
        <div class="charts-grid">
            <div class="chart-card">
                <div class="chart-title">
                    <i class="fas fa-chart-pie"></i> Notes by Priority
                </div>
                <canvas id="priorityChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-title">
                    <i class="fas fa-chart-line"></i> Activity Timeline
                </div>
                <canvas id="activityChart"></canvas>
            </div>
        </div>

        <!-- Tabs -->
        <div class="tabs">
            <button class="tab-btn active" onclick="switchTab('users')">
                <i class="fas fa-users"></i> Users
            </button>
            <button class="tab-btn" onclick="switchTab('notes')">
                <i class="fas fa-sticky-note"></i> Notes
            </button>
            <button class="tab-btn" onclick="switchTab('tags')">
                <i class="fas fa-tags"></i> Tags
            </button>
            <button class="tab-btn" onclick="switchTab('activity')">
                <i class="fas fa-history"></i> Recent Activity
            </button>
        </div>

        <!-- Users Tab -->
        <div id="usersTab" class="tab-content active">
            <div class="search-box">
                <input type="text" class="search-input" id="userSearch" placeholder="🔍 Search users..." onkeyup="filterUsers()">
            </div>
            <div class="table-container">
                <table class="data-table" id="usersTable">
                    <thead>
                        <tr><th>ID</th><th>Username</th><th>Email</th><th>Timezone</th><th>Notes Count</th><th>Joined</th></tr>
                    </thead>
                    <tbody id="usersBody">
                        <tr><td colspan="6" class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Notes Tab -->
        <div id="notesTab" class="tab-content">
            <div class="search-box">
                <input type="text" class="search-input" id="noteSearch" placeholder="🔍 Search notes..." onkeyup="filterNotes()">
                <select id="priorityFilter" class="search-input" style="width: auto;" onchange="filterNotes()">
                    <option value="">All Priorities</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                </select>
            </div>
            <div class="table-container">
                <table class="data-table" id="notesTable">
                    <thead>
                        <tr><th>ID</th><th>Title</th><th>Content</th><th>Priority</th><th>Tags</th><th>Status</th><th>User</th><th>Updated</th></tr>
                    </thead>
                    <tbody id="notesBody">
                        <tr><td colspan="8" class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tags Tab -->
        <div id="tagsTab" class="tab-content">
            <div class="table-container">
                <table class="data-table" id="tagsTable">
                    <thead><tr><th>ID</th><th>Tag Name</th><th>Usage Count</th><th>Notes</th></tr></thead>
                    <tbody id="tagsBody">
                        <tr><td colspan="4" class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Activity Tab -->
        <div id="activityTab" class="tab-content">
            <div class="table-container">
                <table class="data-table" id="activityTable">
                    <thead><tr><th>Note Title</th><th>Action</th><th>User</th><th>Timestamp</th></tr></thead>
                    <tbody id="activityBody">
                        <tr><td colspan="4" class="loading"><i class="fas fa-spinner fa-spin"></i> Loading...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Note Detail Modal -->
    <div id="noteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle"></h2>
                <span class="close-modal" onclick="closeModal()">&times;</span>
            </div>
            <div id="modalContent"></div>
        </div>
    </div>

    <script>
        let allUsers = [];
        let allNotes = [];
        let priorityChart, activityChart;

        // Load all data
        async function loadStats() {
            const response = await fetch('/api/stats');
            const data = await response.json();
            document.getElementById('totalUsers').textContent = data.total_users;
            document.getElementById('totalNotes').textContent = data.total_notes;
            document.getElementById('activeNotes').textContent = data.active_notes;
            document.getElementById('archivedNotes').textContent = data.archived_notes;
            document.getElementById('deletedNotes').textContent = data.deleted_notes;
            document.getElementById('totalTags').textContent = data.total_tags;
        }

        async function loadUsers() {
            const response = await fetch('/api/users');
            allUsers = await response.json();
            displayUsers(allUsers);
        }

        function displayUsers(users) {
            const tbody = document.getElementById('usersBody');
            tbody.innerHTML = '';
            users.forEach(user => {
                const row = tbody.insertRow();
                row.insertCell(0).textContent = user.id;
                row.insertCell(1).innerHTML = `<strong>${escapeHtml(user.username)}</strong>`;
                row.insertCell(2).textContent = user.email;
                row.insertCell(3).textContent = user.timezone;
                row.insertCell(4).textContent = user.notes_count || 0;
                row.insertCell(5).textContent = user.created_at || 'N/A';
            });
        }

        function filterUsers() {
            const search = document.getElementById('userSearch').value.toLowerCase();
            const filtered = allUsers.filter(user => 
                user.username.toLowerCase().includes(search) || 
                user.email.toLowerCase().includes(search)
            );
            displayUsers(filtered);
        }

        async function loadNotes() {
            const response = await fetch('/api/notes');
            allNotes = await response.json();
            displayNotes(allNotes);
            updateCharts();
        }

        function displayNotes(notes) {
            const tbody = document.getElementById('notesBody');
            tbody.innerHTML = '';
            notes.forEach(note => {
                const row = tbody.insertRow();
                row.onclick = () => showNoteDetail(note);
                row.insertCell(0).textContent = note.id;
                row.insertCell(1).innerHTML = `<strong>${escapeHtml(note.title)}</strong>`;
                row.insertCell(2).innerHTML = escapeHtml(note.content || '').substring(0, 100);
                
                const priorityClass = `badge badge-${note.priority}`;
                row.insertCell(3).innerHTML = `<span class="${priorityClass}">${note.priority.toUpperCase()}</span>`;
                
                const tagsHtml = note.tags.map(t => `<span class="tag">#${escapeHtml(t)}</span>`).join('');
                row.insertCell(4).innerHTML = tagsHtml || '-';
                
                let statusBadge = '';
                if (note.is_deleted) statusBadge = '<span class="badge badge-deleted">Deleted</span>';
                else if (note.is_archived) statusBadge = '<span class="badge badge-archived">Archived</span>';
                else statusBadge = '<span class="badge badge-active">Active</span>';
                row.insertCell(5).innerHTML = statusBadge;
                
                row.insertCell(6).textContent = note.username;
                row.insertCell(7).textContent = note.updated_at || 'N/A';
            });
        }

        function filterNotes() {
            const search = document.getElementById('noteSearch').value.toLowerCase();
            const priority = document.getElementById('priorityFilter').value;
            
            const filtered = allNotes.filter(note => {
                const matchesSearch = note.title.toLowerCase().includes(search) || 
                                     (note.content || '').toLowerCase().includes(search);
                const matchesPriority = !priority || note.priority === priority;
                return matchesSearch && matchesPriority;
            });
            displayNotes(filtered);
        }

        async function loadTags() {
            const response = await fetch('/api/tags');
            const tags = await response.json();
            const tbody = document.getElementById('tagsBody');
            tbody.innerHTML = '';
            tags.forEach(tag => {
                const row = tbody.insertRow();
                row.insertCell(0).textContent = tag.id;
                row.insertCell(1).innerHTML = `<span class="tag">#${escapeHtml(tag.name)}</span>`;
                row.insertCell(2).textContent = tag.usage_count || 0;
                row.insertCell(3).innerHTML = tag.notes.map(n => `<span class="tag">${escapeHtml(n)}</span>`).join('') || '-';
            });
        }

        async function loadActivity() {
            const response = await fetch('/api/activity');
            const activities = await response.json();
            const tbody = document.getElementById('activityBody');
            tbody.innerHTML = '';
            activities.forEach(activity => {
                const row = tbody.insertRow();
                row.insertCell(0).innerHTML = `<strong>${escapeHtml(activity.title)}</strong>`;
                row.insertCell(1).innerHTML = `<span class="badge badge-active">${activity.action}</span>`;
                row.insertCell(2).textContent = activity.username;
                row.insertCell(3).textContent = activity.timestamp;
            });
        }

        function updateCharts() {
            // Priority Chart
            const priorities = { high: 0, medium: 0, low: 0 };
            allNotes.forEach(note => {
                if (priorities[note.priority] !== undefined) priorities[note.priority]++;
            });
            
            if (priorityChart) priorityChart.destroy();
            const priorityCtx = document.getElementById('priorityChart').getContext('2d');
            priorityChart = new Chart(priorityCtx, {
                type: 'doughnut',
                data: {
                    labels: ['High Priority', 'Medium Priority', 'Low Priority'],
                    datasets: [{
                        data: [priorities.high, priorities.medium, priorities.low],
                        backgroundColor: ['#ef4444', '#f59e0b', '#10b981'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { labels: { color: 'white', font: { size: 12 } } }
                    }
                }
            });

            // Activity Chart (last 7 days)
            const last7Days = [];
            for (let i = 6; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                last7Days.push(date.toLocaleDateString());
            }
            
            const counts = new Array(7).fill(0);
            allNotes.forEach(note => {
                if (note.updated_at) {
                    const noteDate = new Date(note.updated_at).toLocaleDateString();
                    const index = last7Days.indexOf(noteDate);
                    if (index !== -1) counts[index]++;
                }
            });
            
            if (activityChart) activityChart.destroy();
            const activityCtx = document.getElementById('activityChart').getContext('2d');
            activityChart = new Chart(activityCtx, {
                type: 'line',
                data: {
                    labels: last7Days,
                    datasets: [{
                        label: 'Notes Updated',
                        data: counts,
                        borderColor: '#f093fb',
                        backgroundColor: 'rgba(240, 147, 251, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { labels: { color: 'white' } }
                    },
                    scales: {
                        y: { ticks: { color: 'white' }, grid: { color: 'rgba(255,255,255,0.1)' } },
                        x: { ticks: { color: 'white' }, grid: { color: 'rgba(255,255,255,0.1)' } }
                    }
                }
            });
        }

        function showNoteDetail(note) {
            document.getElementById('modalTitle').textContent = note.title;
            document.getElementById('modalContent').innerHTML = `
                <p><strong>Content:</strong></p>
                <p style="margin: 10px 0; padding: 15px; background: #f3f4f6; border-radius: 10px;">${escapeHtml(note.full_content || note.content || '')}</p>
                <p><strong>Priority:</strong> <span class="badge badge-${note.priority}">${note.priority.toUpperCase()}</span></p>
                <p><strong>Tags:</strong> ${note.tags.map(t => `<span class="tag">#${escapeHtml(t)}</span>`).join('')}</p>
                <p><strong>Created:</strong> ${note.created_at}</p>
                <p><strong>Updated:</strong> ${note.updated_at}</p>
                ${note.reminder_time ? `<p><strong>Reminder:</strong> ${note.reminder_time}</p>` : ''}
                ${note.expiry_date ? `<p><strong>Expires:</strong> ${note.expiry_date}</p>` : ''}
                <p><strong>Author:</strong> ${note.username}</p>
            `;
            document.getElementById('noteModal').style.display = 'flex';
        }

        function closeModal() {
            document.getElementById('noteModal').style.display = 'none';
        }

        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function switchTab(tab) {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            event.target.closest('.tab-btn').classList.add('active');
            
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.getElementById(`${tab}Tab`).classList.add('active');
        }

        async function refreshAll() {
            await Promise.all([loadStats(), loadUsers(), loadNotes(), loadTags(), loadActivity()]);
        }

        // Initial load
        refreshAll();
        setInterval(refreshAll, 30000);
    </script>
</body>
</html>
"""

# API Routes
@app.route('/')
def index():
    """Main dashboard page"""
    return render_template_string(HTML_TEMPLATE)

@app.route('/api/stats')
def get_stats():
    """Get database statistics"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM user")
    total_users = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM note")
    total_notes = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM note WHERE is_deleted = 0 AND is_archived = 0")
    active_notes = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM note WHERE is_archived = 1")
    archived_notes = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM note WHERE is_deleted = 1")
    deleted_notes = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM tag")
    total_tags = cursor.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'total_users': total_users,
        'total_notes': total_notes,
        'active_notes': active_notes,
        'archived_notes': archived_notes,
        'deleted_notes': deleted_notes,
        'total_tags': total_tags
    })

@app.route('/api/users')
def get_users():
    """Get all users with note counts"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT u.id, u.username, u.email, u.timezone, u.created_at,
               COUNT(n.id) as notes_count
        FROM user u
        LEFT JOIN note n ON u.id = n.user_id
        GROUP BY u.id
        ORDER BY u.id
    """)
    users = cursor.fetchall()
    
    result = []
    for user in users:
        result.append({
            'id': user[0],
            'username': user[1],
            'email': user[2],
            'timezone': user[3],
            'created_at': format_datetime(user[4]),
            'notes_count': user[5]
        })
    
    conn.close()
    return jsonify(result)

@app.route('/api/notes')
def get_notes():
    """Get all notes with details"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT n.id, n.title, n.content, n.priority, 
               n.created_at, n.updated_at, n.reminder_time, 
               n.expiry_date, n.due_date, n.is_archived, 
               n.is_deleted, u.username
        FROM note n
        JOIN user u ON n.user_id = u.id
        ORDER BY n.updated_at DESC
    """)
    notes = cursor.fetchall()
    
    result = []
    for note in notes:
        cursor.execute("""
            SELECT t.name FROM tag t
            JOIN note_tags nt ON t.id = nt.tag_id
            WHERE nt.note_id = ?
        """, (note[0],))
        tags = [tag[0] for tag in cursor.fetchall()]
        
        result.append({
            'id': note[0],
            'title': note[1],
            'content': (note[2][:200] + '...') if note[2] and len(note[2]) > 200 else (note[2] or ''),
            'full_content': note[2],
            'priority': note[3],
            'created_at': format_datetime(note[4]),
            'updated_at': format_datetime(note[5]),
            'reminder_time': format_datetime(note[6]),
            'expiry_date': format_datetime(note[7]),
            'due_date': format_datetime(note[8]),
            'is_archived': bool(note[9]),
            'is_deleted': bool(note[10]),
            'username': note[11],
            'tags': tags
        })
    
    conn.close()
    return jsonify(result)

@app.route('/api/tags')
def get_tags():
    """Get all tags with usage"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT t.id, t.name, COUNT(nt.note_id) as usage_count
        FROM tag t
        LEFT JOIN note_tags nt ON t.id = nt.tag_id
        GROUP BY t.id
        ORDER BY t.name
    """)
    tags = cursor.fetchall()
    
    result = []
    for tag in tags:
        cursor.execute("""
            SELECT n.title FROM note n
            JOIN note_tags nt ON n.id = nt.note_id
            WHERE nt.tag_id = ?
        """, (tag[0],))
        notes = [note[0] for note in cursor.fetchall()]
        
        result.append({
            'id': tag[0],
            'name': tag[1],
            'usage_count': tag[2],
            'notes': notes[:5]  # Show first 5 notes
        })
    
    conn.close()
    return jsonify(result)

@app.route('/api/activity')
def get_activity():
    """Get recent activity"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT title, updated_at, username, 'updated' as action
        FROM note n
        JOIN user u ON n.user_id = u.id
        WHERE updated_at >= datetime('now', '-7 days')
        ORDER BY updated_at DESC
        LIMIT 20
    """)
    activities = cursor.fetchall()
    
    result = []
    for activity in activities:
        result.append({
            'title': activity[0],
            'timestamp': format_datetime(activity[1]),
            'username': activity[2],
            'action': activity[3]
        })
    
    conn.close()
    return jsonify(result)

def get_db_connection():
    """Create database connection"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def format_datetime(date_string):
    """Format datetime for display"""
    if not date_string:
        return None
    try:
        dt = datetime.fromisoformat(date_string)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except:
        return date_string

if __name__ == '__main__':
    # Check if database exists
    if not os.path.exists(DB_PATH):
        print(f"❌ Database not found at: {DB_PATH}")
        print("👉 Please run 'python app.py' first to create the database.")
        exit(1)
    
    print("="*60)
    print("🚀 NovaNotes Database Viewer")
    print("="*60)
    print(f"📁 Database: {DB_PATH}")
    print(f"📊 Size: {os.path.getsize(DB_PATH) / 1024:.2f} KB")
    print("="*60)
    print("\n✨ Premium Features:")
    print("   • Real-time statistics dashboard")
    print("   • Interactive charts (Priority distribution + Activity timeline)")
    print("   • Search & filter functionality")
    print("   • Click on notes to view full details")
    print("   • Automatic refresh every 30 seconds")
    print("="*60)
    print("\n🌐 Starting web server...")
    print("👉 Open your browser and go to: http://localhost:8082")
    print("="*60)
    
    app.run(host='0.0.0.0', debug=False, port=8082)