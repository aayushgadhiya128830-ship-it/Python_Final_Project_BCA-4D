// Dark mode toggle
const themeToggle = document.getElementById('themeToggle');
if (themeToggle) {
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark');
        localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
    });
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark');
    }
}

// Auto-dismiss toasts after 3 seconds
document.querySelectorAll('.toast').forEach(toast => {
    setTimeout(() => toast.remove(), 3000);
});

// Optional: live search (if you prefer client-side)
const searchInput = document.querySelector('.search-form input');
if (searchInput) {
    // server-side already works, but you could add AJAX
}